import { readFile } from "node:fs/promises";

export async function loadLibrary() {
  const [catalog, notes] = await Promise.all(["catalog.json", "problems.json"].map(async file =>
    JSON.parse(await readFile(new URL(file, import.meta.url), "utf8"))
  ));
  const notesById = new Map(notes.map(({ id, statement, constraints, example, rubric }) => [id, { statement, constraints, example, rubric }]));
  const ids = new Set(catalog.map(problem => problem.id));
  if (ids.size !== catalog.length || notesById.size !== notes.length || notes.some(note => !ids.has(note.id))) {
    throw new Error("题库包含重复题号或未匹配的站内题面。");
  }
  return catalog.map(problem => ({ ...problem, ...notesById.get(problem.id) }));
}
