# 伊雷娜の猫猫题库

一个中文算法口述训练网站。按平台及独立难度区间抽题，提交解法、正确性说明与复杂度。独立做对的题计入战绩，Codeforces 题按官方难度分加分。已通过的题只计一次。战绩和草稿保存在浏览器本地，历史已计入的分数沿用当时的记分。

## 本地运行

需要 Node.js 22 或更新版本，无需安装第三方依赖。

    node --env-file-if-exists=.env.local local.mjs

打开终端打印的本地地址。运行测试用 node --test。

## 评审

免费的「本机 Qwen」使用 WebLLM 0.2.86 在支持 WebGPU 的浏览器中运行 Qwen3.5-2B。初次使用需要下载约 1.1 GB 的模型文件，用户确认后才开始下载，之后由浏览器缓存。浏览器会从模型项目获取模型，提交的口胡留在设备上。本机小模型的判定适合练习，无法确定时可以用 ChatGPT 复核。

浏览器从 npm 镜像获取固定版本的 WebLLM 运行库，并在执行前校验 SHA-256。运行库和模型使用各自的许可证。模型和编译产物的地址固定在 public/local-ai-worker.js，可从 [WebLLM](https://github.com/mlc-ai/web-llm) 和 [模型卡](https://huggingface.co/Qwen/Qwen3.5-2B) 查看来源。

站内服务从环境变量 OPENAI_API_KEY 读取密钥，模型可通过 OPENAI_MODEL 设置。把本地设置写入未跟踪的 .env.local，部署时通过托管平台的服务端密钥设置配置。提交评审会把题目和解题思路发送给 OpenAI API，判定可能出错。

公开的 ChatGPT Sites 部署应把站长的账号邮箱配置为服务端密钥 JUDGE_OWNER_EMAIL，依靠 Sites 注入的登录身份限制站内评审。匿名及其他用户可以使用评审导入。部署到其他平台时，只有在反向代理会移除客户端传入的身份头、并注入已验证的身份头时才可使用此登录机制，否则公开部署应不配置 OPENAI_API_KEY。

没有配置密钥时，网站支持把评审内容交给 ChatGPT，并导入同一次提交的结果。导入结果适用于个人练习。

## 题库和部署

catalog.json 收录 430 道题。三套难度分别筛选，同一道题有洛谷镜像时可同时显示两套难度。

- Codeforces 收录 160 道，1800、1900、2000、2100 各 40 道。分数来自 [Codeforces 官方 API](https://codeforces.com/apiHelp/methods#problemset.problems)。
- 洛谷原站收录 150 道，绿题 40 道、青题 60 道、蓝题 50 道。颜色来自洛谷题目页及列表。 [洛谷难度体系](https://help.luogu.com.cn/manual/luogu/problem/difficulty)
- AtCoder 收录 120 道，按 1200–2199 区间分段抽样。分数来自 [AtCoder Problems 社区模型](https://github.com/kenkoooo/AtCoderProblems/blob/main/doc/api.md)，页面标注为估计。

难度数据于 2026 年 11 月 21 日采集。problems.json 保存 27 道题的中文简化题面、样例与站内评审参考。其余题在练习页链接原题，并可用 ChatGPT 评审导入战绩。题目权利归其各自权利人，本站代码采用 MIT 许可证。

题面、数据范围、样例及编辑器预览使用随源码分发的 KaTeX 0.19.1。行内公式可用 $...$ 或 \( ... \)，独立公式可用 $$...$$ 或 \[ ... \]。KaTeX 的许可证见 public/vendor/katex-0.19.1/LICENSE。

站点横幅使用用户提供的伊雷娜插画。插画未纳入代码的 MIT 许可证及公开源码压缩包。自行部署时可以把自己的背景图放在 public/elaina-background.jpeg。

运行 node build.mjs 会生成 dist/server/index.js，默认导出兼容 Cloudflare Workers 的 fetch 处理器。可在构建前把公开源码压缩包放在 public/source.zip，让网站提供下载。发布的源码不包含托管身份、本地密钥或战绩。
