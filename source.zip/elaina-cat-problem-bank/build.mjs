import { mkdir, readdir, readFile, writeFile } from "node:fs/promises";
import { loadLibrary } from "./library.mjs";

const assets = {};
for (const name of ["index.html", "style.css", "app.js", "logic.js", "local-ai.js", "local-ai-worker.js", "icon.svg"]) {
  assets[name === "index.html" ? "/" : "/" + name] = await readFile(new URL("./public/" + name, import.meta.url), "utf8");
}
const katexDir = "vendor/katex-0.19.1";
const fontDir = new URL("./public/" + katexDir + "/fonts/", import.meta.url);
for (const name of ["katex.mjs", "katex.min.css", "contrib/auto-render.mjs"]) {
  const path = katexDir + "/" + name;
  assets["/" + path] = await readFile(new URL("./public/" + path, import.meta.url), "utf8");
}
for (const name of await readdir(fontDir)) {
  if (name.endsWith(".woff2")) assets["/" + katexDir + "/fonts/" + name] = (await readFile(new URL(name, fontDir))).toString("base64");
}
try {
  assets["/elaina-background.jpeg"] = (await readFile(new URL("./public/elaina-background.jpeg", import.meta.url))).toString("base64");
} catch (error) {
  if (error.code !== "ENOENT") throw error;
}
try {
  assets.sourceZip = (await readFile(new URL("./public/source.zip", import.meta.url))).toString("base64");
} catch (error) {
  if (error.code !== "ENOENT") throw error;
}
const problems = await loadLibrary();
const server = await readFile(new URL("./server.mjs", import.meta.url), "utf8");
await mkdir(new URL("./dist/server/", import.meta.url), { recursive: true });
await writeFile(new URL("./dist/server/index.js", import.meta.url),
  "const PROBLEMS = " + JSON.stringify(problems) + ";\n" +
  "const ASSETS = " + JSON.stringify(assets) + ";\n" +
  server + "\nexport default makeWorker(PROBLEMS, ASSETS);\n");
try {
  const manifest = await readFile(new URL("./.openai/hosting.json", import.meta.url));
  await mkdir(new URL("./dist/.openai/", import.meta.url), { recursive: true });
  await writeFile(new URL("./dist/.openai/hosting.json", import.meta.url), manifest);
} catch (error) {
  if (error.code !== "ENOENT") throw error;
}
