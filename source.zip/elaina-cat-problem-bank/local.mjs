import { createServer } from "node:http";
import { Readable } from "node:stream";
import "./build.mjs";

const { default: worker } = await import("./dist/server/index.js");

const ip = "127.0.0.1";
const port = Number(process.env.PORT ?? 4173);
const origin = "http://" + ip + ":" + port;
createServer(async (req, res) => {
  try {
    const method = req.method ?? "GET";
    const input = new Request(new URL(req.url ?? "/", origin), {
      method,
      headers: req.headers,
      ...(!["GET", "HEAD"].includes(method) ? { body: Readable.toWeb(req), duplex: "half" } : {})
    });
    const response = await worker.fetch(input, process.env);
    res.writeHead(response.status, Object.fromEntries(response.headers));
    if (response.body) Readable.fromWeb(response.body).pipe(res);
    else res.end();
  } catch {
    res.writeHead(500).end();
  }
}).listen(port, ip, () => console.log("Local " + origin));
