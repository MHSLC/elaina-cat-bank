import assert from "node:assert/strict";
import test from "node:test";
import { chooseProblem, getScore, handoffPrompt, luoguDifficulty, matchingProblems, parseImportedReview } from "./public/logic.js";
import { createLocalReviewer, readLocalVerdict, supportsLocalReview } from "./public/local-ai.js";
import katex from "./public/vendor/katex-0.19.1/katex.mjs";
import { makeWorker } from "./server.mjs";
import { loadLibrary } from "./library.mjs";

const problems = await loadLibrary();
const origin = "https://example.test";
const key = { OPENAI_API_KEY: "test-key" };
const assets = { "/": "<title>伊雷娜の猫猫题库</title>", "/local-ai-worker.js": "" };

test("题库的公式均可解析并生成可读数学标记", () => {
  for (const problem of problems.filter(item => item.statement)) {
    assert.match(problem.constraints, /\$/);
    for (const text of [problem.statement, problem.constraints, problem.example]) {
      const parts = text.split("$");
      assert.equal(parts.length % 2, 1, problem.id);
      for (const formula of parts.filter((_, index) => index % 2)) {
        assert.match(katex.renderToString(formula), /<math/);
      }
    }
  }
});

test("抽题遵守难度、平台、已经结束的题目和历史优先级", () => {
  const pool = matchingProblems(problems, { platform: "Codeforces", min: 1900, max: 1900 }, [
    { problemId: "CF1918D", verdict: "pass" },
    { problemId: "CF2049D", verdict: "skip" }
  ]);
  assert.equal(pool.length, 38);
  assert.ok(pool.every(problem => problem.rating === 1900 && problem.platform === "Codeforces"));
  assert.equal(chooseProblem(pool, [pool[0].id, pool[1].id], pool[0].id, () => 0).id, pool[2].id);
  assert.equal(chooseProblem([], [], null), null);
});

test("各平台筛选使用原有标尺，同一题保留两个来源的难度", () => {
  const counts = Object.fromEntries(["Codeforces", "洛谷", "AtCoder"].map(platform =>
    [platform, problems.filter(problem => problem.platform === platform).length]));
  assert.deepEqual(counts, { Codeforces: 160, 洛谷: 150, AtCoder: 120 });
  for (const [id, rating, color] of [["CF1998D", 2100, "绿"], ["CF1918D", 1900, "青"]]) {
    const p = problems.find(item => item.id === id);
    assert.equal(p.rating, rating);
    assert.equal(luoguDifficulty(p.mirror.difficulty).color, color);
  }
  const cyan = matchingProblems(problems, { platform: "洛谷", min: 5, max: 5 }, []);
  assert.equal(cyan.length, 60);
  assert.ok(cyan.every(p => p.difficulty === 5 && !("rating" in p)));
  const atcoder = matchingProblems(problems, { platform: "AtCoder", min: 1600, max: 1600 }, []);
  assert.equal(atcoder.length, 24);
  assert.ok(atcoder.every(p => p.estimate >= 1600 && p.estimate < 1800 && !("rating" in p)));
  assert.equal(matchingProblems(problems, { platform: "all", detailedOnly: true }, []).length, 27);
});

test("答错和认输记零，重试通过只计一次", () => {
  assert.deepEqual(getScore([
    { problemId: "a", rating: 1900, verdict: "fail" },
    { problemId: "a", rating: 1900, verdict: "pass" },
    { problemId: "a", rating: 1900, verdict: "pass" },
    { problemId: "b", rating: 2100, verdict: "skip" },
    { problemId: "c", points: 0, verdict: "pass" }
  ]), { score: 1900, solved: 2 });
});

test("只读入和本次提交匹配的 ChatGPT 判定", () => {
  const expected = { problemId: "CF1918D", reviewId: "123" };
  const data = JSON.stringify({ ...expected, verdict: "pass" });
  assert.equal(parseImportedReview(data, expected), "pass");
  assert.equal(parseImportedReview(JSON.stringify({ ...expected, verdict: "uncertain" }), expected), "uncertain");
  assert.throws(() => parseImportedReview(data, { ...expected, reviewId: "456" }), /不匹配/);
});

test("原题链接可用于评审交接，站内评审不会猜测缺少资料的题", async () => {
  const problem = problems.find(item => !item.statement);
  const prompt = handoffPrompt(problem, "测试", "linked");
  assert.ok(prompt.includes(problem.url));
  assert.match(prompt, /无法读取原题，请判 uncertain/);
  const worker = makeWorker(problems, assets, () => assert.fail("unexpected API call"));
  const response = await worker.fetch(new Request(origin + "/api/judge", {
    method: "POST",
    body: JSON.stringify({ problemId: problem.id, answer: "测试" })
  }), key);
  assert.equal(response.status, 422);
  assert.equal((await worker.fetch(new Request(origin + "/api/local-rubric?problemId=" + problem.id))).status, 404);
});

function submit(worker, answer, env = {}, requestOrigin = origin) {
  return worker.fetch(new Request(origin + "/api/judge", {
    method: "POST",
    headers: { Origin: requestOrigin },
    body: JSON.stringify({ problemId: "CF1918D", answer })
  }), env);
}

test("公开题库不包含参考解，无密钥时不发起请求", async () => {
  const worker = makeWorker(problems, assets, () => assert.fail("unexpected API call"));
  const catalog = await worker.fetch(new Request(origin + "/api/catalog"));
  const data = await catalog.json();
  assert.equal(data.problems.length, problems.length);
  assert.ok(!data.problems.some(problem => "rubric" in problem));
  assert.equal(data.autoJudge, false);
  assert.equal((await submit(worker, "口胡")).status, 503);
  assert.equal((await submit(worker, "口胡", key, "https://external.test")).status, 403);
  assert.equal((await submit(worker, "", key)).status, 400);
});

test("站内评审只返回判定，兼容 Responses 输出结构", async () => {
  for (const verdict of ["pass", "fail"]) {
    const worker = makeWorker(problems, assets, async (url, options) => {
      assert.equal(url, "https://api.openai.com/v1/responses");
      const payload = JSON.parse(options.body);
      assert.equal(payload.store, false);
      assert.equal(payload.text.format.strict, true);
      assert.ok(JSON.parse(payload.input).reference.includes("二分"));
      return Response.json({
        output: [
          { type: "reasoning" },
          { type: "message", content: [{ type: "output_text", text: JSON.stringify({ verdict, explanation: "答案不应透出" }) }] }
        ]
      });
    });
    const response = await submit(worker, "测试口胡", key);
    assert.equal(response.status, 200);
    assert.deepEqual(await response.json(), { verdict });
  }
});

test("额度不足时提示转用 ChatGPT 评审", async () => {
  const worker = makeWorker(problems, assets, async () =>
    Response.json({ error: { code: "credit_balance_exhausted" } }, { status: 429 })
  );
  const response = await submit(worker, "测试口胡", key);
  assert.equal(response.status, 503);
  assert.match((await response.json()).error, /额度已用完/);
});

test("开放题库时只允许已验证的站长使用站内评审", async () => {
  const env = { ...key, JUDGE_OWNER_EMAIL: "Owner@example.test" };
  let upstreamRequests = 0;
  const worker = makeWorker(problems, assets, async () => {
    upstreamRequests++;
    return Response.json({ output: [{ content: [{ type: "output_text", text: '{"verdict":"pass"}' }] }] });
  });
  const get = headers => worker.fetch(new Request(origin + "/api/catalog", { headers }), env);
  const call = headers => worker.fetch(new Request(origin + "/api/judge", {
    method: "POST",
    headers,
    body: JSON.stringify({ problemId: "CF1918D", answer: "测试口胡" })
  }), env);

  const nobody = await (await get({})).json();
  assert.equal(nobody.autoJudge, false);
  assert.equal(nobody.ownerSignIn, true);
  assert.equal(nobody.problems.length, problems.length);
  assert.equal((await call({})).status, 403);
  assert.equal((await call({ "oai-authenticated-user-email": "owner@example.test" })).status, 403);
  assert.equal((await call({
    "oai-authenticated-user-id": "visitor",
    "oai-authenticated-user-email": "visitor@example.test"
  })).status, 403);

  const owner = {
    "oai-authenticated-user-id": "owner-site-id",
    "oai-authenticated-user-email": "owner@example.test"
  };
  assert.equal((await (await get(owner)).json()).autoJudge, true);
  assert.equal((await call(owner)).status, 200);
  assert.equal(upstreamRequests, 1);
});

test("本机评审先检查 WebGPU，并校验模型判定", async () => {
  assert.equal(await supportsLocalReview({}, true), false);
  assert.equal(await supportsLocalReview({ gpu: { requestAdapter: async () => ({}) } }, false), false);
  assert.equal(await supportsLocalReview({ gpu: { requestAdapter: async () => ({}) } }, true), true);
  assert.equal(await supportsLocalReview({ gpu: { requestAdapter: async () => null } }, true), false);
  assert.equal(readLocalVerdict('{"verdict":"pass"}'), "pass");
  assert.equal(readLocalVerdict('<think>推理结束</think>\n{"verdict":"uncertain"}'), "uncertain");
  assert.throws(() => readLocalVerdict('{"verdict":"猜测"}'));
});

test("本机评审报告进度、复用模型并支持取消", async () => {
  let created = 0, terminated = 0;
  class TestWorker extends EventTarget {
    postMessage(input) {
      queueMicrotask(() => {
        this.dispatchEvent(new MessageEvent("message", { data: { type: "progress", value: .5 } }));
        if (input !== "停留") this.dispatchEvent(new MessageEvent("message", { data: { type: "verdict", verdict: "pass" } }));
      });
    }
    terminate() { terminated++; }
  }
  const review = createLocalReviewer(() => { created++; return new TestWorker(); });
  const progress = [];
  assert.equal(await review("评审", { onProgress: value => progress.push(value) }), "pass");
  assert.deepEqual(progress, [.5]);
  assert.equal(await review("再评审"), "pass");
  assert.equal(created, 1);
  const controller = new AbortController();
  const pending = review("停留", { signal: controller.signal });
  controller.abort();
  await assert.rejects(pending, { name: "AbortError" });
  assert.equal(terminated, 1);
  assert.equal(await review("稍后再试"), "pass");
  assert.equal(created, 2);
});

test("本机评审仅在请求单题时提供要点，并在独立工作线程允许模型加载", async () => {
  const worker = makeWorker(problems, assets, () => assert.fail("unexpected API call"));
  const rubric = await worker.fetch(new Request(origin + "/api/local-rubric?problemId=CF1918D"));
  assert.equal(rubric.status, 200);
  assert.match((await rubric.json()).rubric, /二分/);
  assert.equal((await worker.fetch(new Request(origin + "/api/local-rubric?problemId=missing"))).status, 404);
  const script = await worker.fetch(new Request(origin + "/local-ai-worker.js"));
  assert.match(script.headers.get("Content-Security-Policy"), /wasm-unsafe-eval/);
  assert.match(script.headers.get("Content-Security-Policy"), /https:\/\/cdn\.jsdelivr\.net/);
  const page = await worker.fetch(new Request(origin + "/"));
  assert.doesNotMatch(page.headers.get("Content-Security-Policy"), /cdn\.jsdelivr\.net/);
});
